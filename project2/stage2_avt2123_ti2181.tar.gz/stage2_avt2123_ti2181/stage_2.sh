#!/bin/bash
python queryEvaluator.py $1 $2